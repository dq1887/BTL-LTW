TV4 HRM - FRONTEND

Goi tach tu source HRM tong hop ngay 09-11. Day la project phan frontend day du cua ban tich hop, khong phai module doc lap.

Luu y khi dua len Git:
- Khong commit node_modules, file .env, thong tin mat khau/token hoac du lieu MongoDB that.
- Backend can frontend va cac API/schema dung chung cua HRM; frontend can backend dang chay.
- Kiem tra va gop voi nhanh cua nhom, tranh ghi de file cung duong dan cua TV khac.
