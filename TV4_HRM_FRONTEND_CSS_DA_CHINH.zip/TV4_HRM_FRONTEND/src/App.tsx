import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { MainLayout } from "./components/layouts/MainLayout";
import Dashboard from "./components/layouts/Dashboard";
import { Shifts } from "./pages/Shifts";
import { Login } from "./pages/Login";
import { ProtectedRoute } from "./components/ProtectedRoute";

// 1. Import 2 màn hình của TV3
import AttendancePage from "./pages/AttendancePage";
import AdjustmentsPage from "./pages/AdjustmentsPage";
import LeavePage from "./pages/LeavePage";
import EmployeesPage from "./pages/EmployeesPage";
import DepartmentsPage from "./pages/DepartmentsPage";
import SchedulesReadOnlyPage from "./pages/SchedulesReadOnlyPage";
import PayrollAwaitingModule from "./pages/PayrollAwaitingModule";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Route công khai: Đăng nhập */}
        <Route path="/login" element={<Login />} />

        {/* Các route yêu cầu đăng nhập */}
        <Route element={<ProtectedRoute />}>
          <Route
            path="/*"
            element={
              <MainLayout>
                <Routes>
                  <Route
                    path="/"
                    element={<Navigate to="/dashboard" replace />}
                  />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/shifts" element={<Shifts />} />
                  <Route path="/schedules" element={<SchedulesReadOnlyPage />} />
                  <Route path="/payroll" element={<PayrollAwaitingModule />} />
                  <Route path="/employees" element={<EmployeesPage />} />
                  <Route path="/departments" element={<DepartmentsPage />} />

                  {/* 2. Đăng ký 2 route của TV3 tại đây */}
                  <Route path="/attendance" element={<AttendancePage />} />
                  <Route
                    path="/attendance-adjustments"
                    element={<AdjustmentsPage />}
                  />

                  <Route path="/leave-requests" element={<LeavePage />} />
                  <Route path="/leave-types" element={<LeavePage />} />

                  {/* Fallback điều hướng về dashboard */}
                  <Route
                    path="*"
                    element={<Navigate to="/dashboard" replace />}
                  />
                </Routes>
              </MainLayout>
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
