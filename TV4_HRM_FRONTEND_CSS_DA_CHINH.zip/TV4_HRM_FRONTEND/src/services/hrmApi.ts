import {authService} from './authService';
export async function hrmApi<T>(path:string,method='GET',body?:unknown):Promise<T>{
 const token=authService.getToken();
 const response=await fetch('/api'+path,{method,headers:{...(token?{Authorization:'Bearer '+token}:{}),...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})});
 const raw:unknown=await response.json().catch(()=>({}));
 if(!response.ok){const error=(raw&&typeof raw==='object'&&'message' in raw&&typeof raw.message==='string')?raw.message:'Không thể thực hiện yêu cầu.';if(response.status===401){authService.logout()}throw new Error(error)}
 return raw as T;
}
export type Department={_id:string,code:string,name:string,status:'active'|'inactive',description?:string,managerId?:null|{_id:string,fullName:string,email:string}};
export type Employee={_id:string,employeeCode:string,fullName:string,email:string,phone:string,departmentId:string|{_id:string,name:string,code:string},position:string,role:'admin_hr'|'manager'|'employee',status:'active'|'inactive',salary:number};
export const depId=(e:Employee)=>typeof e.departmentId==='string'?e.departmentId:e.departmentId?._id;
export const depName=(e:Employee)=>typeof e.departmentId==='string'?e.departmentId:e.departmentId?.name||'Chưa xác định';
