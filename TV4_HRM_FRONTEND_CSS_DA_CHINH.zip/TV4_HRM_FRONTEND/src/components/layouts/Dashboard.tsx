import {useEffect,useState} from 'react';
import {Link} from 'react-router-dom';
import {authService} from '../../services/authService';
import {hrmApi,type Department,type Employee} from '../../services/hrmApi';
import './Dashboard.css';
type Leave={id:string,status:string,employeeId?:{fullName:string}|string};
type Schedule={_id:string,workDate:string,shiftId:string};
const dateVN=()=>new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date());
const monthVN=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit'}).format(new Date());
export default function Dashboard(){
 const me=authService.getCurrentUser();const [busy,setBusy]=useState(true),[error,setError]=useState('');
 const [employees,setEmployees]=useState<Employee[]>([]),[departments,setDepartments]=useState<Department[]>([]),[leaves,setLeaves]=useState<Leave[]>([]),[attendances,setAttendances]=useState(0),[schedules,setSchedules]=useState<Schedule[]>([]);
 useEffect(()=>{let active=true;(async()=>{
 try{
  const all=await Promise.allSettled([
   hrmApi<{employees:Employee[]}>('/employees?limit=100'),
   hrmApi<Department[]>('/departments'),
   hrmApi<{success:boolean,data:Leave[]}>('/leave-requests'),
   hrmApi<{success:boolean,data:unknown[]}>('/attendances?month='+monthVN()),
   hrmApi<{success:boolean,data:Schedule[]}>('/schedules')
  ]);
  if(!active)return;
  if(all[0].status==='fulfilled')setEmployees(all[0].value.employees);
  if(all[1].status==='fulfilled')setDepartments(all[1].value);
  if(all[2].status==='fulfilled')setLeaves(all[2].value.data);
  if(all[3].status==='fulfilled')setAttendances(all[3].value.data.length);
  if(all[4].status==='fulfilled')setSchedules(all[4].value.data);
  if(all.every(x=>x.status==='rejected'))setError('Không đọc được dữ liệu máy chủ. Vui lòng kiểm tra đăng nhập và kết nối backend.');
 }catch(e){if(active)setError(e instanceof Error?e.message:'Không kết nối được máy chủ')}
 finally{if(active)setBusy(false)}
 })();return()=>{active=false}},[]);
 const pending=leaves.filter(x=>x.status==='pending').length;
 const stats=[{label:'Nhân viên trong phạm vi quyền',value:String(employees.length),link:'/employees'},{label:'Phòng ban',value:String(departments.length),link:'/departments'},{label:'Bản ghi công tháng này (cá nhân)',value:String(attendances),link:'/attendance'},{label:'Đơn nghỉ chờ duyệt (theo quyền)',value:String(pending),link:'/leave-requests'}];
 return <div className="dashboard"><div className="welcome-row"><div><h1>Xin chào, {me?.fullName||me?.name||'bạn'}!</h1><p>Dữ liệu trực tiếp từ API HRM tích hợp TV1, TV3 và TV4.</p></div><div className="today-date">{dateVN()}</div></div>
 {error&&<p style={{padding:14,background:'#fee2e2',color:'#991b1b',borderRadius:8}}>{error}</p>}
 <section className="stats-grid">{stats.map((x,i)=><Link to={x.link} key={x.label} className={'stat-card '+(['blue','green','orange','purple'][i])} style={{textDecoration:'none'}}><div className="stat-copy"><strong>{busy?'…':x.value}</strong><span>{x.label}</span></div></Link>)}</section>
 <section className="middle-grid"><article className="panel department-panel" style={{padding:22}}><h2>Nhân sự theo phòng ban</h2><div style={{display:'grid',gap:12,marginTop:18}}>{departments.map(d=><div key={d._id} style={{display:'flex',justifyContent:'space-between',borderBottom:'1px solid #e2e8f0',paddingBottom:10}}><span>{d.name}</span><strong>{employees.filter(e=>String(typeof e.departmentId==='string'?e.departmentId:e.departmentId?._id)===d._id).length} người</strong></div>)}{!departments.length&&<p>Chưa có phòng ban hoặc backend chưa chạy.</p>}</div><p style={{color:'#64748b',fontSize:12}}>Đếm theo danh sách nhân viên mà tài khoản hiện tại được phép xem, tối đa 100 bản ghi.</p></article>
 <article className="panel attendance-panel" style={{padding:22}}><h2>Liên kết nghiệp vụ</h2><p>TV1: nhân viên và trưởng phòng → TV4: gửi/duyệt đơn → TV3: khóa ghi công trùng ngày đã duyệt → TV5: dữ liệu ngày nghỉ có lương, không lương.</p><div style={{display:'flex',flexWrap:'wrap',gap:10,marginTop:18}}><Link to="/employees">Nhân viên</Link><Link to="/leave-requests">Nghỉ phép</Link><Link to="/attendance">Chấm công</Link></div></article></section>
 <section className="bottom-grid"><article className="panel schedule-panel" style={{padding:22}}><h2>Lịch làm việc đã công bố (tài khoản hiện tại)</h2>{schedules.filter(x=>x.workDate>=new Date().toISOString().slice(0,10)).slice(0,8).map(s=><div key={s._id} style={{padding:'9px 0',borderBottom:'1px solid #eee'}}><strong>{s.workDate}</strong><span style={{marginLeft:16,color:'#475569'}}>Đã có lịch</span></div>)}{!schedules.length&&<p>Chưa có lịch. Chạy seed:integration để tạo lịch demo; sau này TV2 cung cấp lịch thật.</p>}</article>
 <article className="panel activity-panel" style={{padding:22}}><h2>Việc cần xử lý</h2><p>Có <strong>{pending}</strong> đơn nghỉ đang chờ trong phạm vi quyền của bạn.</p><Link to="/leave-requests">Mở màn hình nghỉ phép</Link><hr/><p style={{fontSize:13,color:'#64748b'}}>Bảng lương của TV5 chưa được ghép; mục lương không sử dụng số liệu giả.</p></article></section>
 </div>;
}
