import {useCallback,useEffect,useState} from 'react';
import {authService} from '../services/authService';
import {hrmApi,type Employee} from '../services/hrmApi';
import './hrmTables.css';
type Schedule = {_id:string, employeeId:string, workDate:string, status:'draft'|'published', shiftId:string};
type Shift = {_id:string,name:string,startTime:string,endTime:string};
/** Bảng chỉ đọc lịch demo. API lịch CRUD đầy đủ thuộc trách nhiệm TV2. */
export default function SchedulesReadOnlyPage(){
  const user=authService.getCurrentUser();
  const [people,setPeople]=useState<Employee[]>([]);
  const [employeeId,setEmployeeId]=useState(user?.id||'');
  const [items,setItems]=useState<Schedule[]>([]);
  const [shifts,setShifts]=useState<Shift[]>([]);
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(false);
  const load=useCallback(async()=>{
    if(!employeeId)return;
    setLoading(true);setError('');
    try {
      const [s,sh]=await Promise.all([
        hrmApi<{success:boolean,data:Schedule[]}>('/schedules?employeeId='+encodeURIComponent(employeeId)),
        hrmApi<Shift[]>('/shifts')
      ]);
      setItems(s.data||[]);setShifts(sh);
    }catch(e){setError(e instanceof Error?e.message:'Không đọc được lịch')}
    finally{setLoading(false)}
  },[employeeId]);
  useEffect(()=>{
    if(!user||user.role==='employee')return;
    void hrmApi<{employees:Employee[]}>('/employees?limit=100').then(r=>setPeople(r.employees||[])).catch(()=>{});
  },[user?.id,user?.role]);
  useEffect(()=>{void load()},[load]);
  return <div className="hrm-page"><header className="hrm-title"><div>
    <h1>Lịch làm việc – kiểm tra tích hợp</h1>
    <p>Đây chỉ là màn hình đọc lịch mẫu để TV4 đối chiếu ngày nghỉ. TV2 cần bàn giao module lịch phân ca thật.</p>
  </div></header><section className="hrm-panel">
    {user?.role!=='employee' && <label>Nhân viên: <select value={employeeId} onChange={e=>setEmployeeId(e.target.value)}>
      {user&&<option value={user.id}>Bản thân ({user.name||user.fullName||user.email})</option>}
      {people.filter(e=>e._id!==user?.id).map(e=><option key={e._id} value={e._id}>{e.fullName} – {e.employeeCode}</option>)}
    </select></label>}
    {error&&<p className="hrm-alert">{error}</p>}
    {loading&&<p>Đang tải lịch…</p>}
    <div className="hrm-tablewrap"><table><thead><tr><th>Ngày</th><th>Ca làm</th><th>Giờ bắt đầu</th><th>Giờ kết thúc</th><th>Trạng thái</th></tr></thead><tbody>
      {items.map(x=>{const sh=shifts.find(s=>s._id===x.shiftId);return <tr key={x._id}><td>{x.workDate}</td><td>{sh?.name||x.shiftId}</td><td>{sh?.startTime||'—'}</td><td>{sh?.endTime||'—'}</td><td>{x.status}</td></tr>})}
      {!items.length&&!loading&&<tr><td colSpan={5}>Chưa có lịch cho nhân viên này; hãy chạy seed:integration trên DB demo.</td></tr>}
    </tbody></table></div>
  </section></div>;
}
