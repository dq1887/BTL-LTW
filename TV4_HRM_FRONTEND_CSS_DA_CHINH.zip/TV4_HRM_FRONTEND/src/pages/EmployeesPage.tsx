import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {authService} from '../services/authService';
import {hrmApi,depId,depName,type Department,type Employee} from '../services/hrmApi';
import './hrmTables.css';
const blank={employeeCode:'',fullName:'',email:'',password:'',phone:'',departmentId:'',position:'Nhân viên',role:'employee',salary:'0'};
type FormState=typeof blank;
const roles:{[k:string]:string}={admin_hr:'Nhân sự (HR)',manager:'Trưởng phòng',employee:'Nhân viên'};
export default function EmployeesPage(){
 const role=authService.getCurrentUser()?.role;const canEdit=role==='admin_hr';
 const [list,setList]=useState<Employee[]>([]),[deps,setDeps]=useState<Department[]>([]),[page,setPage]=useState(1),[pages,setPages]=useState(1),[search,setSearch]=useState('');
 const [form,setForm]=useState<FormState>(blank),[editing,setEditing]=useState<Employee|null>(null),[showForm,setShowForm]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [transfer,setTransfer]=useState<Employee|null>(null),[destination,setDestination]=useState('');
 const load=useCallback(async()=>{try{setError('');const [es,ds]=await Promise.all([hrmApi<{employees:Employee[],pages:number}>('/employees?page='+page+'&limit=12&search='+encodeURIComponent(search)),hrmApi<Department[]>('/departments')]);setList(es.employees);setPages(es.pages||1);setDeps(ds)}catch(e){setError(e instanceof Error?e.message:'Không thể tải dữ liệu')}},[page,search]);
 useEffect(()=>{void load()},[load]);
 const startCreate=()=>{setEditing(null);setForm({...blank,departmentId:deps.find(x=>x.status==='active')?._id||''});setShowForm(true);setError('');};
 const startEdit=(e:Employee)=>{setEditing(e);setForm({employeeCode:e.employeeCode,fullName:e.fullName,email:e.email,password:'',phone:e.phone||'',departmentId:depId(e),position:e.position||'',role:e.role,salary:String(e.salary||0)});setShowForm(true);setError('')};
 const update=(k:keyof FormState,v:string)=>setForm(x=>({...x,[k]:v}));
 const save=async(ev:FormEvent)=>{ev.preventDefault();setBusy(true);setError('');setMessage('');try{
 const data:Record<string,unknown>={employeeCode:form.employeeCode.trim(),fullName:form.fullName.trim(),email:form.email.trim().toLowerCase(),phone:form.phone,departmentId:form.departmentId,position:form.position,role:form.role,salary:Number(form.salary)||0};
 if(form.password)data.password=form.password;
 if(editing){delete data.employeeCode;delete data.departmentId;await hrmApi('/employees/'+editing._id,'PATCH',data)}else await hrmApi('/employees','POST',data);
 setMessage(editing?'Cập nhật thành công':'Đã tạo nhân viên');setShowForm(false);await load();
 }catch(e){setError(e instanceof Error?e.message:'Không lưu được')}finally{setBusy(false)}};
 const transferEmployee=async()=>{if(!transfer||!destination)return;try{setBusy(true);setError('');await hrmApi('/employees/'+transfer._id+'/transfer','PATCH',{newDepartmentId:destination});setTransfer(null);setMessage('Điều chuyển thành công');await load()}catch(e){setError(e instanceof Error?e.message:'Không thể điều chuyển')}finally{setBusy(false)}};
 const disable=async(e:Employee)=>{if(!window.confirm('Ngừng hoạt động tài khoản '+e.fullName+'?'))return;try{setError('');await hrmApi('/employees/'+e._id,'DELETE');setMessage('Đã khóa nhân viên');await load()}catch(err){setError(err instanceof Error?err.message:'Không thể khóa')}};
 return <div className="hrm-page"><header className="hrm-title"><div><h1>Quản lý nhân viên</h1><p>TV1 • Dữ liệu nhân viên dùng chung cho nghỉ phép, chấm công và lương</p></div>{canEdit&&<button className="hrm-primary" onClick={startCreate}>+ Thêm nhân viên</button>}</header>
 <section className="hrm-panel"><div className="hrm-toolbar"><input placeholder="Tìm mã, tên hoặc email" value={search} onChange={e=>{setSearch(e.target.value);setPage(1)}}/><span>{list.length} nhân viên ở trang này</span></div>
 {error&&<p className="hrm-alert">{error}</p>}{message&&<p className="hrm-success">{message}</p>}
 <div className="hrm-tablewrap"><table><thead><tr><th>Mã NV</th><th>Họ tên</th><th>Email</th><th>Phòng ban</th><th>Vai trò</th><th>Trạng thái</th>{canEdit&&<th>Thao tác</th>}</tr></thead><tbody>
 {list.map(e=><tr key={e._id}><td>{e.employeeCode}</td><td><strong>{e.fullName}</strong><small>{e.position}</small></td><td>{e.email}</td><td>{depName(e)}</td><td>{roles[e.role]||e.role}</td><td><span className={e.status==='active'?'hrm-pill':'hrm-pill muted'}>{e.status==='active'?'Hoạt động':'Đã khóa'}</span></td>{canEdit&&<td className="hrm-actions"><button onClick={()=>startEdit(e)}>Sửa</button><button onClick={()=>{setTransfer(e);setDestination(deps.find(x=>x._id!==depId(e)&&x.status==='active')?._id||'')}}>Điều chuyển</button>{e.status==='active'&&<button onClick={()=>void disable(e)}>Khóa</button>}</td>}</tr>)}
 {!list.length&&<tr><td colSpan={canEdit?7:6}>Không tìm thấy nhân viên.</td></tr>}
 </tbody></table></div><div className="hrm-pagination"><button disabled={page===1} onClick={()=>setPage(x=>x-1)}>Trước</button><span>Trang {page}/{pages}</span><button disabled={page>=pages} onClick={()=>setPage(x=>x+1)}>Sau</button></div></section>
 {showForm&&<div className="hrm-overlay"><form className="hrm-dialog" onSubmit={e=>void save(e)}><h2>{editing?'Cập nhật nhân viên':'Thêm nhân viên'}</h2><div className="hrm-fields">
 {!editing&&<label>Mã nhân viên<input required value={form.employeeCode} onChange={e=>update('employeeCode',e.target.value)}/></label>}
 <label>Họ tên<input required value={form.fullName} onChange={e=>update('fullName',e.target.value)}/></label><label>Email<input required type="email" value={form.email} onChange={e=>update('email',e.target.value)}/></label>
 <label>{editing?'Mật khẩu mới (để trống nếu không đổi)':'Mật khẩu (ít nhất 8 ký tự)'}<input type="password" minLength={8} required={!editing} value={form.password} onChange={e=>update('password',e.target.value)}/></label>
 <label>Điện thoại<input value={form.phone} onChange={e=>update('phone',e.target.value)}/></label><label>Chức vụ<input value={form.position} onChange={e=>update('position',e.target.value)}/></label>
 {!editing&&<label>Phòng ban<select required value={form.departmentId} onChange={e=>update('departmentId',e.target.value)}><option value="">Chọn phòng ban</option>{deps.filter(d=>d.status==='active').map(d=><option value={d._id} key={d._id}>{d.name}</option>)}</select></label>}
 <label>Vai trò<select value={form.role} onChange={e=>update('role',e.target.value)}>{Object.entries(roles).map(([r,n])=><option value={r} key={r}>{n}</option>)}</select></label>
 <label>Lương cơ bản (VND)<input type="number" min={0} value={form.salary} onChange={e=>update('salary',e.target.value)}/></label>
 </div><div className="hrm-dialog-actions"><button type="button" onClick={()=>setShowForm(false)}>Hủy</button><button className="hrm-primary" disabled={busy}>{busy?'Đang lưu...':'Lưu'}</button></div></form></div>}
 {transfer&&<div className="hrm-overlay"><div className="hrm-dialog"><h2>Điều chuyển {transfer.fullName}</h2><p>Phòng hiện tại: {depName(transfer)}</p><label>Phòng đích<select value={destination} onChange={e=>setDestination(e.target.value)}>{deps.filter(d=>d.status==='active'&&d._id!==depId(transfer)).map(d=><option key={d._id} value={d._id}>{d.name}</option>)}</select></label><div className="hrm-dialog-actions"><button onClick={()=>setTransfer(null)}>Hủy</button><button className="hrm-primary" disabled={!destination||busy} onClick={()=>void transferEmployee()}>Xác nhận điều chuyển</button></div></div></div>}
 </div>;
}
