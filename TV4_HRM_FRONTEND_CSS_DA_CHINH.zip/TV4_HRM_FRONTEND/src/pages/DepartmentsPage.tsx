import {useCallback,useEffect,useState,type FormEvent} from 'react';
import {authService} from '../services/authService';
import {hrmApi,depId,type Department,type Employee} from '../services/hrmApi';
import './hrmTables.css';
type EditForm={code:string,name:string,description:string,status:'active'|'inactive',managerId:string};
const blank:EditForm={code:'',name:'',description:'',status:'active',managerId:''};
export default function DepartmentsPage(){
 const isHr=authService.getCurrentUser()?.role==='admin_hr';
 const [deps,setDeps]=useState<Department[]>([]),[employees,setEmployees]=useState<Employee[]>([]),[editing,setEditing]=useState<Department|null>(null),[form,setForm]=useState<EditForm>(blank),[showForm,setShowForm]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false);
 const load=useCallback(async()=>{try{setError('');const [d,e]=await Promise.all([hrmApi<Department[]>('/departments'),isHr?hrmApi<{employees:Employee[]}>('/employees?limit=100'):Promise.resolve({employees:[]})]);setDeps(d);setEmployees(e.employees)}catch(err){setError(err instanceof Error?err.message:'Không tải được dữ liệu')}},[isHr]);
 useEffect(()=>{void load()},[load]);
 const start=(d?:Department)=>{setEditing(d||null);setForm(d?{code:d.code,name:d.name,description:d.description||'',status:d.status,managerId:d.managerId?._id||''}:blank);setShowForm(true);setError('')};
 const update=(k:keyof EditForm,v:string)=>setForm(s=>({...s,[k]:v}));
 const save=async(ev:FormEvent)=>{ev.preventDefault();setBusy(true);setError('');setMessage('');try{
  const payload=editing?form:{code:form.code,name:form.name,description:form.description,status:form.status};
  await hrmApi('/departments'+(editing?'/'+editing._id:''),editing?'PATCH':'POST',payload);
  setShowForm(false);setMessage(editing?'Đã cập nhật phòng ban':'Đã tạo phòng ban');await load();
 }catch(err){setError(err instanceof Error?err.message:'Không lưu được')}finally{setBusy(false)}};
 const remove=async(d:Department)=>{if(!window.confirm('Xóa phòng '+d.name+'? Chỉ được xóa khi chưa có nhân viên.'))return;try{await hrmApi('/departments/'+d._id,'DELETE');setMessage('Đã xóa phòng ban');await load()}catch(err){setError(err instanceof Error?err.message:'Không xóa được')}};
 return <div className="hrm-page"><header className="hrm-title"><div><h1>Quản lý phòng ban</h1><p>TV1 • Trưởng phòng được liên kết với quyền duyệt nghỉ phép TV4</p></div>{isHr&&<button className="hrm-primary" onClick={()=>start()}>+ Thêm phòng ban</button>}</header><section className="hrm-panel">
 {error&&<p className="hrm-alert">{error}</p>}{message&&<p className="hrm-success">{message}</p>}
 <div className="hrm-tablewrap"><table><thead><tr><th>Mã phòng</th><th>Tên phòng ban</th><th>Trưởng phòng</th><th>Trạng thái</th><th>Mô tả</th>{isHr&&<th>Thao tác</th>}</tr></thead><tbody>
 {deps.map(d=><tr key={d._id}><td><strong>{d.code}</strong></td><td>{d.name}</td><td>{d.managerId?.fullName||<em>Chưa phân công</em>}</td><td><span className={d.status==='active'?'hrm-pill':'hrm-pill muted'}>{d.status==='active'?'Hoạt động':'Đã khóa'}</span></td><td>{d.description||'—'}</td>{isHr&&<td className="hrm-actions"><button onClick={()=>start(d)}>Sửa / gán trưởng phòng</button><button onClick={()=>void remove(d)}>Xóa</button></td>}</tr>)}
 {!deps.length&&<tr><td colSpan={isHr?6:5}>Chưa có phòng ban.</td></tr>}
 </tbody></table></div></section>
 {showForm&&<div className="hrm-overlay"><form className="hrm-dialog" onSubmit={e=>void save(e)}><h2>{editing?'Cập nhật phòng ban':'Thêm phòng ban'}</h2><div className="hrm-fields">
 <label>Mã phòng<input required value={form.code} onChange={e=>update('code',e.target.value)}/></label><label>Tên phòng ban<input required value={form.name} onChange={e=>update('name',e.target.value)}/></label>
 <label>Trạng thái<select value={form.status} onChange={e=>update('status',e.target.value)}><option value="active">Hoạt động</option><option value="inactive">Đã khóa</option></select></label>
 {editing&&<label>Trưởng phòng (để trống nếu chưa phân công)<select value={form.managerId} onChange={e=>update('managerId',e.target.value)}><option value="">Chưa phân công</option>{employees.filter(e=>e.role==='manager'&&e.status==='active'&&depId(e)===editing._id).map(e=><option key={e._id} value={e._id}>{e.fullName} – {e.employeeCode}</option>)}</select></label>}
 <label className="hrm-full">Mô tả<textarea rows={2} value={form.description} onChange={e=>update('description',e.target.value)}/></label></div>
 {editing&&<p className="hrm-note">Muốn gán trưởng phòng: tạo nhân viên với vai trò Manager thuộc phòng này trước, sau đó quay lại chọn tên.</p>}
 <div className="hrm-dialog-actions"><button type="button" onClick={()=>setShowForm(false)}>Hủy</button><button className="hrm-primary" disabled={busy}>{busy?'Đang lưu...':'Lưu'}</button></div></form></div>}
 </div>;
}
