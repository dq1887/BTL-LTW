/** TV5 chưa bàn giao module tính lương trong bộ source hiện tại. */
export default function PayrollAwaitingModule() {
  return (
    <main className="hrm-page">
      <header className="hrm-title">
        <div>
          <h1>Bảng lương</h1>
          <p>Vị trí tích hợp dành cho TV5. Chức năng tính lương và chốt bảng lương sẽ được kết nối khi nhận source chính thức.</p>
        </div>
      </header>
      <section className="hrm-panel">
        <h2>Đang chờ module TV5</h2>
        <p>Hiện tại hệ thống mới có điểm tham chiếu dữ liệu lương để kiểm tra nghiệp vụ hủy đơn nghỉ phép đã duyệt. Chưa có giao diện hoặc API tính lương hoàn chỉnh.</p>
      </section>
    </main>
  );
}
