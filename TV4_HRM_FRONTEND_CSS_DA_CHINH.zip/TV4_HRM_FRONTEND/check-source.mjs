import fs from 'node:fs';import path from 'node:path';import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);let ts;try{ts=require('typescript')}catch{ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript')}
const root=path.resolve('src');let count=0;let problems=[];
function scan(dir){for(const item of fs.readdirSync(dir)){const f=path.join(dir,item);if(fs.statSync(f).isDirectory()){scan(f);continue}if(!/\.(ts|tsx)$/.test(f))continue;const s=fs.readFileSync(f,'utf8');const ext=f.endsWith('tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS;const source=ts.createSourceFile(f,s,ts.ScriptTarget.ESNext,true,ext);count++;
for(const d of source.parseDiagnostics)problems.push({file:path.relative(root,f),diagnostic:ts.flattenDiagnosticMessageText(d.messageText,' ')});
for(const stmt of source.statements){if((ts.isImportDeclaration(stmt)||ts.isExportDeclaration(stmt)) && stmt.moduleSpecifier?.text?.startsWith('.')) {const imp=stmt.moduleSpecifier.text;const base=path.resolve(path.dirname(f),imp);if(!['','.tsx','.ts','.js','.jsx','/index.ts','/index.tsx'].some(ext=>fs.existsSync(base+ext)))problems.push({file:path.relative(root,f),import:imp});}}
}}
scan(root);if(problems.length){console.error(JSON.stringify(problems,null,2));process.exitCode=1}else console.log('PASS: '+count+' TS/TSX files parsed; all relative imports resolve. This is not a full typecheck/build.');
