const express = require('express');
const router = express.Router();
const leaveTypeController = require('../controllers/leaveTypeController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);
router.use(authorize('admin_hr', 'manager'));

router.route('/')
    .get(leaveTypeController.getAllLeaveTypes)
    .post(leaveTypeController.createLeaveType);

router.route('/:id')
    .put(leaveTypeController.updateLeaveType)
    .delete(leaveTypeController.deleteLeaveType);

module.exports = router;
