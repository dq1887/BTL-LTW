const express = require('express');
const router = express.Router();
const leaveController = require('../controllers/leaveController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.use(protect);

router.route('/')
    .get(leaveController.getAllLeaveRequests)
    .post(leaveController.createLeaveRequest);

router.get('/stats', leaveController.getLeaveStats);
router.get('/types', leaveController.getLeaveTypesForUser);

router.route('/:id')
    .put(leaveController.updateLeaveRequest)
    .delete(authorize('admin_hr', 'manager'), leaveController.deleteLeaveRequest);

router.put('/:id/cancel', leaveController.cancelLeaveRequest);
router.put('/:id/process', authorize('admin_hr', 'manager'), leaveController.processLeaveRequest);

module.exports = router;
