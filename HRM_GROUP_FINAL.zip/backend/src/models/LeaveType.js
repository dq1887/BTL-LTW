const mongoose = require('mongoose');

const leaveTypeSchema = new mongoose.Schema({
    name: { type: String, required: [true, 'Tên loại nghỉ phép là bắt buộc'], unique: true },
    description: { type: String },
    defaultDays: { type: Number, required: [true, 'Số ngày nghỉ mặc định là bắt buộc'] },
    isActive: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('LeaveType', leaveTypeSchema);
