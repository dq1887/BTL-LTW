const LeaveType = require('../models/LeaveType');
const catchAsync = require('../utils/catchAsync');

exports.getAllLeaveTypes = catchAsync(async (req, res) => {
    const leaveTypes = await LeaveType.find();
    res.status(200).json({ success: true, data: leaveTypes });
});

exports.createLeaveType = catchAsync(async (req, res) => {
    const leaveType = await LeaveType.create(req.body);
    res.status(201).json({ success: true, data: leaveType });
});

exports.updateLeaveType = catchAsync(async (req, res) => {
    const leaveType = await LeaveType.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!leaveType) return res.status(404).json({ success: false, message: 'Không tìm thấy loại nghỉ phép' });
    res.status(200).json({ success: true, data: leaveType });
});

exports.deleteLeaveType = catchAsync(async (req, res) => {
    const leaveType = await LeaveType.findByIdAndDelete(req.params.id);
    if (!leaveType) return res.status(404).json({ success: false, message: 'Không tìm thấy loại nghỉ phép' });
    res.status(200).json({ success: true, message: 'Đã xóa loại nghỉ phép' });
});
