const LeaveRequest = require('../models/LeaveRequest');
const LeaveType = require('../models/LeaveType');
const Attendance = require('../models/Attendance');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');

// Lấy danh sách đơn nghỉ
exports.getAllLeaveRequests = catchAsync(async (req, res) => {
    let filter = {};
    if (req.user.role === 'employee') {
        filter.employeeId = req.user._id;
    }
    const leaves = await LeaveRequest.find(filter)
        .populate('employeeId', 'employeeCode fullName departmentId')
        .populate('leaveTypeId', 'name')
        .populate('approvedBy', 'fullName')
        .sort('-createdAt');
    res.status(200).json({ success: true, data: leaves });
});

exports.getLeaveTypesForUser = catchAsync(async (req, res) => {
    const leaveTypes = await LeaveType.find({ isActive: true });
    res.status(200).json({ success: true, data: leaveTypes });
});

// Tạo đơn xin nghỉ
exports.createLeaveRequest = catchAsync(async (req, res, next) => {
    const { leaveTypeId, startDate, endDate, reason } = req.body;
    
    if (new Date(startDate) > new Date(endDate)) {
        return res.status(400).json({ success: false, message: 'Ngày kết thúc phải sau ngày bắt đầu' });
    }

    const leaveType = await LeaveType.findById(leaveTypeId);
    if (!leaveType || !leaveType.isActive) {
        return res.status(400).json({ success: false, message: 'Loại nghỉ phép không hợp lệ hoặc đã bị khóa' });
    }

    const existingLeave = await LeaveRequest.findOne({
        employeeId: req.user._id,
        status: { $in: ['pending', 'approved'] },
        $or: [
            { startDate: { $lte: endDate }, endDate: { $gte: startDate } }
        ]
    });
    if (existingLeave) {
        return res.status(400).json({ success: false, message: 'Bạn đã có đơn nghỉ phép trùng thời gian này' });
    }

    const leaveRequest = await LeaveRequest.create({
        employeeId: req.user._id,
        leaveTypeId,
        startDate,
        endDate,
        reason
    });

    res.status(201).json({ success: true, data: leaveRequest });
});

// Chỉnh sửa đơn
exports.updateLeaveRequest = catchAsync(async (req, res) => {
    const leave = await LeaveRequest.findById(req.params.id);
    if (!leave) return res.status(404).json({ success: false, message: 'Không tìm thấy đơn nghỉ phép' });
    
    if (leave.employeeId.toString() !== req.user._id.toString()) {
        return res.status(403).json({ success: false, message: 'Bạn không có quyền sửa đơn này' });
    }
    if (leave.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'Chỉ có thể sửa đơn đang chờ duyệt' });
    }

    const updatedLeave = await LeaveRequest.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.status(200).json({ success: true, data: updatedLeave });
});

// Hủy đơn
exports.cancelLeaveRequest = catchAsync(async (req, res) => {
    const leave = await LeaveRequest.findById(req.params.id);
    if (!leave) return res.status(404).json({ success: false, message: 'Không tìm thấy đơn nghỉ phép' });

    if (leave.employeeId.toString() !== req.user._id.toString()) {
        return res.status(403).json({ success: false, message: 'Bạn không có quyền hủy đơn này' });
    }
    if (leave.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'Chỉ có thể hủy đơn đang chờ duyệt' });
    }

    leave.status = 'cancelled';
    await leave.save();
    res.status(200).json({ success: true, data: leave });
});

// Duyệt / Từ chối đơn
exports.processLeaveRequest = catchAsync(async (req, res) => {
    const { status, rejectionReason } = req.body;
    const leave = await LeaveRequest.findById(req.params.id);
    if (!leave) return res.status(404).json({ success: false, message: 'Không tìm thấy đơn nghỉ phép' });

    if (leave.employeeId.toString() === req.user._id.toString()) {
        return res.status(403).json({ success: false, message: 'Không thể tự duyệt đơn của chính mình' });
    }

    if (!['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ success: false, message: 'Trạng thái xử lý không hợp lệ' });
    }

    leave.status = status;
    leave.approvedBy = req.user._id;
    if (status === 'rejected') {
        leave.rejectionReason = rejectionReason;
    }
    
    await leave.save();
    res.status(200).json({ success: true, data: leave });
});

// Xóa đơn (chỉ HR)
exports.deleteLeaveRequest = catchAsync(async (req, res) => {
    const leave = await LeaveRequest.findByIdAndDelete(req.params.id);
    if (!leave) return res.status(404).json({ success: false, message: 'Không tìm thấy đơn nghỉ phép' });
    res.status(200).json({ success: true, message: 'Đã xóa đơn nghỉ phép' });
});

// Tổng hợp ngày nghỉ
exports.getLeaveStats = catchAsync(async (req, res) => {
    const employeeId = req.user.role === 'employee' ? req.user._id : (req.query.employeeId || req.user._id);
    
    const approvedLeaves = await LeaveRequest.find({
        employeeId: employeeId,
        status: 'approved'
    }).populate('leaveTypeId');

    const stats = {};
    approvedLeaves.forEach(leave => {
        if (!leave.leaveTypeId) return;
        const typeName = leave.leaveTypeId.name;
        const days = Math.ceil((new Date(leave.endDate) - new Date(leave.startDate)) / (1000 * 60 * 60 * 24)) + 1;
        
        if (!stats[typeName]) {
            stats[typeName] = { used: 0, default: leave.leaveTypeId.defaultDays };
        }
        stats[typeName].used += days;
    });

    res.status(200).json({ success: true, data: stats });
});
