import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function LeaveRequestsPage() {
    const [requests, setRequests] = useState([]);
    const [leaveTypes, setLeaveTypes] = useState([]);
    const [stats, setStats] = useState({});
    const [loading, setLoading] = useState(false);
    
    const [leaveTypeId, setLeaveTypeId] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [reason, setReason] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const token = localStorage.getItem('token');
    
    const axiosConfig = {
        headers: { Authorization: `Bearer ${token}` }
    };

    const fetchData = async () => {
        setLoading(true);
        try {
            const [reqRes, typesRes, statsRes] = await Promise.all([
                axios.get('http://localhost:5000/api/leaves', axiosConfig),
                axios.get('http://localhost:5000/api/leaves/types', axiosConfig).catch(() => ({ data: { data: [] } })),
                axios.get('http://localhost:5000/api/leaves/stats', axiosConfig)
            ]);
            setRequests(reqRes.data.data);
            setLeaveTypes(typesRes.data.data);
            setStats(statsRes.data.data);
        } catch (err) {
            console.error(err);
        }
        setLoading(false);
    };

    useEffect(() => {
        if (token) fetchData();
    }, [token]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        try {
            await axios.post('http://localhost:5000/api/leaves', {
                leaveTypeId, startDate, endDate, reason
            }, axiosConfig);
            setSuccess('Gửi đơn nghỉ phép thành công!');
            setLeaveTypeId('');
            setStartDate('');
            setEndDate('');
            setReason('');
            fetchData();
        } catch (err: any) {
            setError(err.response?.data?.message || 'Có lỗi xảy ra');
        }
    };

    const handleProcess = async (id: string, status: string) => {
        if (!confirm(`Bạn chắc chắn muốn ${status === 'approved' ? 'Duyệt' : 'Từ chối'} đơn này?`)) return;
        try {
            await axios.put(`http://localhost:5000/api/leaves/${id}/process`, { status }, axiosConfig);
            fetchData();
        } catch (err: any) {
            alert(err.response?.data?.message || 'Có lỗi xảy ra');
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <h2>Quản lý nghỉ phép</h2>
            <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
                <div style={{ flex: 1, padding: '20px', background: '#fff', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                    <h3>Tạo đơn nghỉ phép</h3>
                    {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
                    {success && <div style={{ color: 'green', marginBottom: '10px' }}>{success}</div>}
                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        <div>
                            <label>Loại nghỉ: </label>
                            <select value={leaveTypeId} onChange={e => setLeaveTypeId(e.target.value)} required style={{ width: '100%', padding: '8px' }}>
                                <option value="">-- Chọn loại nghỉ --</option>
                                {leaveTypes.map((t: any) => (
                                    <option key={t._id} value={t._id}>{t.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label>Từ ngày: </label>
                            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required style={{ width: '100%', padding: '8px' }} />
                        </div>
                        <div>
                            <label>Đến ngày: </label>
                            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} required style={{ width: '100%', padding: '8px' }} />
                        </div>
                        <div>
                            <label>Lý do: </label>
                            <textarea value={reason} onChange={e => setReason(e.target.value)} required style={{ width: '100%', padding: '8px' }} />
                        </div>
                        <button type="submit" style={{ padding: '10px', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px' }}>Gửi đơn</button>
                    </form>
                </div>
            </div>
            
            <div style={{ padding: '20px', background: '#fff', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                <h3>Danh sách đơn nghỉ phép</h3>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr style={{ background: '#f8f9fa', textAlign: 'left' }}>
                            <th style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>Nhân viên</th>
                            <th style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>Trạng thái</th>
                            <th style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        {requests.map((r: any) => (
                            <tr key={r._id}>
                                <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{r.employeeId?.fullName}</td>
                                <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{r.status}</td>
                                <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>
                                    {r.status === 'pending' && (
                                        <>
                                            <button onClick={() => handleProcess(r._id, 'approved')} style={{ marginRight: '5px' }}>Duyệt</button>
                                            <button onClick={() => handleProcess(r._id, 'rejected')}>Từ chối</button>
                                        </>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
