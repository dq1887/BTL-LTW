import mongoose from 'mongoose';
import { LeaveType } from '../models/LeaveType.js';
import { LeaveRequest } from '../models/LeaveRequest.js';
import { createLeaveRouter } from '../routes/leaveRoutes.js';
import { createLeaveActorAdapter } from './identityAdapter.js';
import { initHrmLock } from './hrmLock.js';

export async function mountLeaveApi(app, { authenticate, mapVerifiedUser, prefix = '/api' }) {
  if (mongoose.connection.readyState !== 1) throw new Error('Cần MongoDB trước khi khởi tạo nghỉ phép.');
  const hello = await mongoose.connection.db.admin().command({ hello: 1 });
  if (!hello.setName && hello.msg !== 'isdbgrid') {
    throw new Error('Nghỉ phép cần MongoDB Atlas hoặc MongoDB replica set để chạy transaction.');
  }
  await Promise.all([LeaveType.init(), LeaveRequest.init()]);
  await initHrmLock();
  app.use(prefix, createLeaveRouter({ authenticate: [authenticate, createLeaveActorAdapter(mapVerifiedUser)] }));
}
