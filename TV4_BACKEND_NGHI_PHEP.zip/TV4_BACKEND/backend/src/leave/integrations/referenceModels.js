import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const Employee = require('../../models/Employee.js');
const Department = require('../../models/Department.js');
const Shift = require('../../models/Shift.js');
const Attendance = require('../../models/Attendance.js');
const Schedule = require('../../models/Schedule.js');
const Payroll = require('../../models/Payroll.js');
// TV1 dùng Employee là tài khoản; không đăng ký User thứ hai cùng collection.
export { Employee, Department, Shift, Attendance, Schedule, Payroll };
export const User = Employee;
