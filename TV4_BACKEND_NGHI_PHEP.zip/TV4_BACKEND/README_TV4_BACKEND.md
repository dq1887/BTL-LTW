# TV4 – Backend quản lý nghỉ phép

Thư mục `backend/src/leave/` chứa module backend nghỉ phép của TV4: model, routes, controller, service, validator và lớp tích hợp.

## Lưu ý tích hợp
- Đây là phần module TV4 được tách từ source HRM tích hợp, không phải backend HRM độc lập.
- Khi ghép vào backend nhóm, giữ nguyên đường dẫn `src/leave/`.
- Module cần các model dùng chung của HRM (ví dụ Employee, Schedule, Attendance, Payroll) và cấu hình xác thực/kết nối MongoDB từ backend chính. Các model dùng chung không được sao chép vào gói này vì thuộc phần nền tảng/nhóm khác.
- Cần kiểm tra cách mount API trong `integrations/mountLeaveApi.js` với `server.js` của nhóm trước khi chạy.
- Không chứa `.env` hay thông tin bí mật.
